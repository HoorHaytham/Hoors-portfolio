package game.engine.lanes;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

import game.engine.base.Wall;
import game.engine.titans.Titan;
import game.engine.weapons.Weapon;

public class Lane implements Comparable<Lane> {

	// all are read
	private final Wall laneWall;
	private int dangerLevel;// initially set to 0+READ AND WRITE
	private final PriorityQueue<Titan> titans;
	private final ArrayList<Weapon> weapons;

	public Lane(Wall laneWall) {
		this.laneWall = laneWall;
		dangerLevel = 0;
		titans = new PriorityQueue<>();
		weapons = new ArrayList<Weapon>();
	}

	public int compareTo(Lane o) {
		return dangerLevel - o.dangerLevel;
	}

	public int getDangerLevel() {
		return dangerLevel;
	}

	public void setDangerLevel(int dangerLevel) {
		this.dangerLevel = dangerLevel;
	}

	public Wall getLaneWall() {
		return laneWall;
	}

	public PriorityQueue<Titan> getTitans() {
		return titans;
	}

	public ArrayList<Weapon> getWeapons() {
		return weapons;
	}
	public void addTitan(Titan titan){
		if(isLaneLost())
			return;
		titans.add(titan);
	}
	public void addWeapon(Weapon weapon){
		if(isLaneLost())
			return;
		weapons.add(weapon);
	}
	public void moveLaneTitans(){
		if(isLaneLost())
			return;
		Queue<Titan> titansMoved=new LinkedList<>();
		while (! titans.isEmpty()){
			Titan current=titans.poll();
			if(! current.hasReachedTarget()){
			current.move();
		}
			titansMoved.add(current);
		}
		titans.addAll(titansMoved);
		}
	
	public int performLaneWeaponsAttacks(){
		if(this.isLaneLost()){
			updateLaneDangerLevel();
			return 0;}
		int totalResourcesGathered=0;
		for(int i=0;i<weapons.size();i++){
			Weapon current=weapons.get(i);
			int resourcesReturned=current.turnAttack(titans);
			totalResourcesGathered+=resourcesReturned;	
		}
		updateLaneDangerLevel();
		return totalResourcesGathered;
	}
	
	
	public boolean isLaneLost(){
		return laneWall.getCurrentHealth()<=0;
	}
	
	public void updateLaneDangerLevel(){
		if(this.isLaneLost()){
			titans.clear();
			weapons.clear();
			setDangerLevel(0);
			return;}
		Titan[] titansarray = titans.toArray(new Titan[titans.size()]);
		int totalDangerLevel=0;
		for(int i=0;i<titansarray.length;i++){
			Titan current=titansarray[i];
			totalDangerLevel+=current.getDangerLevel();
		}
	   setDangerLevel(totalDangerLevel);
	}
	
	public int performLaneTitansAttacks(){
		if(this.isLaneLost()){
			updateLaneDangerLevel();
			return laneWall.getResourcesValue();}
		Titan[] array = titans.toArray(new Titan[titans.size()]);
		int resourcesFromWall=0;
		for(int i=0;i<array.length;i++){
			Titan currentTitan=array[i];
			if (currentTitan.hasReachedTarget())
			resourcesFromWall+=currentTitan.attack(laneWall);
	}
		updateLaneDangerLevel();
		return resourcesFromWall;
		}

}
