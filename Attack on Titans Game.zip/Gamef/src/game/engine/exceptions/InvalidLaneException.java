package game.engine.exceptions;

@SuppressWarnings("serial")
public class InvalidLaneException extends GameActionException {
	// Attributes
	private static final String MSG = "Action done on an invalid lane";

	// Constructors
	public InvalidLaneException() {
		super(MSG);
	}

	public InvalidLaneException(String message) {
		super(message);
	}
}
