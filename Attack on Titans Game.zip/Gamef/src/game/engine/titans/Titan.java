package game.engine.titans;

import game.engine.interfaces.Attackee;//check
import game.engine.interfaces.Attacker;
import game.engine.interfaces.Mobil;

public abstract class Titan implements Comparable<Titan>, Attackee, Attacker, Mobil {
	private final int baseHealth; // read
	private int currentHealth; // read write through a relevant interface method
	private final int baseDamage; // read
	private final int heightInMeters; // read
	private int distanceFromBase;// read and write through a relevant interface method
	private int speed;// read,write..
	private final int resourcesValue; // read
	private final int dangerLevel;

	public Titan(int baseHealth, int baseDamage, int heightInMeters, int distanceFromBase, int speed,
			int resourcesValue, int dangerLevel) {
		this.baseHealth = baseHealth;
		currentHealth = baseHealth;
		this.baseDamage = baseDamage;
		this.heightInMeters = heightInMeters;
		this.distanceFromBase = distanceFromBase;
		this.speed = speed;
		this.resourcesValue = resourcesValue;
		this.dangerLevel = dangerLevel;
	}

	public int getHeightInMeters() {
		return heightInMeters;
	}

	public int getDangerLevel() {
		return dangerLevel;
	}

	public int compareTo(Titan o) {
		return this.distanceFromBase - o.distanceFromBase;
	}

	public int getCurrentHealth() {
		return currentHealth;
	}

	public void setCurrentHealth(int health) {
		if (health < 0)
			currentHealth = 0;
		else
			currentHealth = health;
	}

	public int getResourcesValue() {
		return resourcesValue;
	}

	public int getDamage() {
		return baseDamage;
	}

	public int getDistance() {
		return distanceFromBase;
	}

	public void setDistance(int distance) {
		if (distance < 0)
			distanceFromBase = 0;
		else
			distanceFromBase = distance;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		if (speed < 0)
			this.speed = 0;
		else
			this.speed = speed;
	}

	public int getBaseHealth() {
		return baseHealth;
	}
}
