package game.engine.dataloader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileReader;
import java.util.HashMap;
import game.engine.titans.TitanRegistry;
import game.engine.weapons.WeaponRegistry;

public class DataLoader {
	private static final String TITANS_FILE_NAME = "titans.csv";
	private static final String WEAPONS_FILE_NAME = "weapons.csv";

	// titans
	public static HashMap<Integer, TitanRegistry> readTitanRegistry() throws IOException {
		HashMap<Integer, TitanRegistry> titans = new HashMap<Integer, TitanRegistry>();
		try {
			BufferedReader buffer = new BufferedReader(new FileReader(TITANS_FILE_NAME));
			String s = "";
			while ((s = buffer.readLine()) != null) {
				String[] a = s.split(",");
				int code = Integer.parseInt(a[0]);
				int baseHealth = Integer.parseInt(a[1]);
				int baseDamage = Integer.parseInt(a[2]);
				int heightInMeters = Integer.parseInt(a[3]);
				int speed = Integer.parseInt(a[4]);
				int resourcesValue = Integer.parseInt(a[5]);
				int dangerLevel = Integer.parseInt(a[6]);
				TitanRegistry t = new TitanRegistry(code, baseHealth, baseDamage, heightInMeters, speed, resourcesValue,
						dangerLevel);
				titans.put(code, t);
			}
			buffer.close();
		} catch (IOException e) {
			e.printStackTrace(); // print the exception in a humane way
		}
		return titans;
	}

	// Weapons
	public static HashMap<Integer, WeaponRegistry> readWeaponRegistry() throws IOException {
		HashMap<Integer, WeaponRegistry> weapons = new HashMap<Integer, WeaponRegistry>();
		try {
			BufferedReader buffer = new BufferedReader(new FileReader(WEAPONS_FILE_NAME));
			String s = "";
			while ((s = buffer.readLine()) != null) {
				String[] a = s.split(",");
				int code = Integer.parseInt(a[0]);
				int price = Integer.parseInt(a[1]);
				int damage = Integer.parseInt(a[2]);
				String name = a[3];
				// Weapon type is VolleySpreadCannon
				if (a.length > 4) {
					int minRange = Integer.parseInt(a[4]);
					int maxRange = Integer.parseInt(a[5]);
					WeaponRegistry t = new WeaponRegistry(code, price, damage, name, minRange, maxRange);
					weapons.put(code, t);
				} else {
					WeaponRegistry t = new WeaponRegistry(code, price, damage, name);
					weapons.put(code, t);
				}
			}
			buffer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return weapons;
	}

	public String getTITANS_FILE_NAME() {
		return TITANS_FILE_NAME;
	}

	public String getWEAPONS_FILE_NAME() {
		return WEAPONS_FILE_NAME;
	}
}
