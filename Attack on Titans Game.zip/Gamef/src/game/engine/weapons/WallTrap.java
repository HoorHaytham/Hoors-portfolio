package game.engine.weapons;

import game.engine.titans.Titan;

import java.util.PriorityQueue;

public class WallTrap extends Weapon{
final public static int WEAPON_CODE =4;
	
	public WallTrap(int baseDamage) {
		
		super(baseDamage);
		
	}

	public int turnAttack(PriorityQueue<Titan> laneTitans){
		if (! laneTitans.isEmpty()){
		Titan current=laneTitans.poll();
			if(current.getDistance()<=0){
				int resourcesReturned=attack(current);
				if(resourcesReturned==0)
					laneTitans.add(current);
				return resourcesReturned;
			}
			else{
				laneTitans.add(current);
				return 0;
			}
				
	}
		else 
			return 0;
}
}
