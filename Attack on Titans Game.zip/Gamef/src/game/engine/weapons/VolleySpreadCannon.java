package game.engine.weapons;

import game.engine.titans.Titan;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class VolleySpreadCannon extends Weapon{
	 final public static int WEAPON_CODE =3;
	 final private int minRange;
	 final private int maxRange;
	
	

	public VolleySpreadCannon(int baseDamage, int minRange, int maxRange) {
		super(baseDamage);
		this.minRange = minRange;
		this.maxRange = maxRange;
	}

	public int getMinRange() {
		return minRange;
	}

	public int getMaxRange() {
		return maxRange;
	}

	public int turnAttack(PriorityQueue<Titan> laneTitans){
		Queue<Titan> titansChecked=new LinkedList<>();
		int totalResources=0;
		while(! laneTitans.isEmpty()){
			Titan current=laneTitans.poll();
			int distance=current.getDistance();
			if(distance>=minRange && distance<=maxRange)
			{
				int resourcesReturned=attack(current);
				totalResources+=resourcesReturned;
				if(resourcesReturned==0)
					titansChecked.add(current);
			}
			else
			titansChecked.add(current);	
		}
		laneTitans.addAll(titansChecked);
		return totalResources;
	}

}
