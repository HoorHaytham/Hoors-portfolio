package game.engine.weapons;

import game.engine.titans.Titan;

import java.util.PriorityQueue;

public class SniperCannon extends Weapon{
final public static int WEAPON_CODE =2;
	
	public SniperCannon(int baseDamage) {
		super(baseDamage);
		
	}

	public int turnAttack(PriorityQueue<Titan> laneTitans){
		if (! laneTitans.isEmpty()){
			Titan current=laneTitans.poll();
			int resourcesReturned= attack(current);
			if(resourcesReturned==0)
				laneTitans.add(current);
			return resourcesReturned;
		}
		else
			return 0;
	}
}
