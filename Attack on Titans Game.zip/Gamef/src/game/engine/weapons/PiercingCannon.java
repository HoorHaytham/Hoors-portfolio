package game.engine.weapons;

import game.engine.titans.Titan;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class PiercingCannon extends Weapon {
	final public static int WEAPON_CODE = 1;

	public PiercingCannon(int baseDamage) {
		super(baseDamage);

	}
	
	public int turnAttack(PriorityQueue<Titan> laneTitans){
		Queue<Titan> titansChecked=new LinkedList<>();
		int totalResources=0;
		for(int i=0;i<5 && !laneTitans.isEmpty();i++){
			Titan current=laneTitans.poll();
			int resourcesReturned=attack(current);
			totalResources+=resourcesReturned;
			if (resourcesReturned==0)
				titansChecked.add(current);
		}
		laneTitans.addAll(titansChecked);
		return totalResources;	
	}
	}
