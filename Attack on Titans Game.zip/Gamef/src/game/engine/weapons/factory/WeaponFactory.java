package game.engine.weapons.factory;
import game.engine.dataloader.DataLoader;
import game.engine.exceptions.InsufficientResourcesException;
import game.engine.weapons.Weapon;
import game.engine.weapons.WeaponRegistry;

import java.io.IOException;
import java.util.HashMap;

public class WeaponFactory {
	private final HashMap<Integer, WeaponRegistry> weaponShop;//read 
		
	public WeaponFactory() throws IOException {
			this.weaponShop = DataLoader.readWeaponRegistry();// same as dataloader wala im confused..

		}

		public HashMap<Integer, WeaponRegistry> getWeaponShop() {
			return weaponShop;
		}
		
		public FactoryResponse buyWeapon(int resources, int weaponCode) throws InsufficientResourcesException{
			WeaponRegistry weaponRegistry=weaponShop.get(weaponCode);
			Weapon weapon=weaponRegistry.buildWeapon();
			int price=weaponRegistry.getPrice();
			if(price>resources){
				throw new InsufficientResourcesException("Not enough resources",resources);
			}
			else{
				int remainingResources=resources-price;
				return new FactoryResponse(weapon,remainingResources);
				
			}
		}
		public void addWeaponToShop(int code, int price){
			WeaponRegistry weaponRegistry=new WeaponRegistry(code,price);
			weaponShop.put(code, weaponRegistry);
		}
		public void addWeaponToShop(int code, int price, int damage, String name){
			WeaponRegistry weaponRegistry=new WeaponRegistry(code,price,damage,name);
			weaponShop.put(code, weaponRegistry);
		}
		public void addWeaponToShop(int code, int price, int damage, String name, int minRange,
				int maxRange){
			WeaponRegistry weaponRegistry=new WeaponRegistry(code,price,damage,name,minRange,maxRange);
			weaponShop.put(code, weaponRegistry);
		}
}
